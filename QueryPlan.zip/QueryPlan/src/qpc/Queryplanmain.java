package qpc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLXML;
import java.sql.Statement;
import java.util.ArrayList;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;



//import com.darkprograms.speech.translator.GoogleTranslate;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import java.io.File;

import org.w3c.dom.Document;

import com.darkprograms.speech.synthesiser.SynthesiserV2;
import com.gtranslate.Audio;
import com.gtranslate.Language;
import com.gtranslate.Translator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;

public class Queryplanmain {
	
	static SynthesiserV2 synthesizer = new SynthesiserV2("AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");
	
	public static void main(String[] args) {
		System.out
				.println("-------- PostgreSQL JDBC Connection Testing ------------");
		// Pathname of XML file to be written to.
		// NOTE To-Change based on different computers
		String FILENAME = "D:\\QueryPlanConverter\\QueryPlan\\QueryPlan.xml";

		// Test if Postgres Drivers are installed correctly
		try {
			Class.forName("org.postgresql.Driver");

		} catch (ClassNotFoundException e) {
			System.out.println("Where is your PostgreSQL JDBC Driver? "
					+ "Include in your library path!");
			e.printStackTrace();
			return;
		}
		System.out.println("PostgreSQL JDBC Driver Registered!");
		
		// -------------------------------------------------------------- End of
		// Driver Test

		//For SQL queries
		Connection connection = null;
		Statement stmt = null;
		
		
		
		/////////////////
		//Write to XML document
		Document mapDoc = null;
		//Text to speech object using FreeTTS API
		//Translator translate = Translator.getInstance();
		//Language language = Language.getInstance();
		
		
		try {
			DocumentBuilderFactory.newInstance();

		} catch (Exception e) {
			System.out.println("Problem creating document: " + e.getMessage());
		}

		//Try connection to PostgreSQL database, parameter #1= username, parameter#2 = database password
		try {

			connection = DriverManager.getConnection(
					"jdbc:postgresql://127.0.0.1:5432/CZ4031", "postgres",
					"123456");

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
		if (connection != null) {
			System.out.println("Connection Success!");
		} else {
			System.out.println("Failed to make connection!");
		}
		
		
		while (true) {

			//Enable write to file
			FileWriter fw;
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					System.in));	
			ArrayList resultSet = new ArrayList();
			int counter = 0;
			try {
				// Get query from user
				System.out.println("Enter Query:");
				String query = reader.readLine();
				fw = new FileWriter(FILENAME);
				BufferedWriter bw = new BufferedWriter(fw);
				stmt = connection.createStatement();
				//Execute Query with EXPLAIN (analyze, FORMAT XML) to
				//output in XML format
				ResultSet rs = stmt
						.executeQuery("EXPLAIN (analyze, FORMAT XML) " + query);
				System.out.println();
				bw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
				while (rs.next()) {		
					resultSet.add(rs.getSQLXML(1).getString());
					bw.write(resultSet.get(counter).toString());
					counter++;
				}
				bw.close();
				

				
				File fXmlFile = new File(
						"D:\\QueryPlanConverter\\QueryPlan\\QueryPlan.xml");
				DocumentBuilderFactory dbf = DocumentBuilderFactory
						.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(fXmlFile);
				doc.getDocumentElement().normalize();
			
				String output = "The execution of this Query begins by running ";
				String hashJoin = "";
				String seqScan = "";
				String indexScan = "";
				String bitmapHeapScan = "";
				String bitmapIndexScan = "";
				String bitmapTables = "";
				String mergeJoins = "";
				String indexOnlyScan = "";
				int noOfIndexOnlyScan = 0;
				int noOfMergeJoins = 0;
				int noOfIndexScan = 0;
				int noOfBitmapHeapScanTables = 0;
				int noOfBitmapHeapScan = 0;
				int noOfBitmapIndexScan = 0;
				int root = 1;
				int subTree = 0;
				int seqsScan = 0;
				int hashsJoin = 0;
				String planningTime = "";
				int noOfSort = 0;
				String sortMethod = "";

				String exeTime = "";
				//Store in List to use to check for repeated tables
				ArrayList<String> list = new ArrayList<String>();
				ArrayList<String> sortlist = new ArrayList<String>();
				ArrayList<String> mergelist = new ArrayList<String>();

				NodeList nodeList = doc.getElementsByTagName("*");
				for (int i = 0; i < nodeList.getLength(); i++) {
					// Get element
					Element element = (Element) nodeList.item(i);

					if (!element.getNodeName().contains("Plan")
							&& !element.getNodeName().contains("Triggers")) {

						if (root == 1) {
							if ((element.getNodeName().equals("Node-Type"))) {

								if (element.getFirstChild().getNodeValue()
										.equals("Aggregate")) {
									Element temp = (Element) nodeList
											.item(i + 1);
									output += "an Aggregate Operation using "
											+ temp.getFirstChild()
													.getNodeValue()
											+ " Strategy on the result sets of its sub branches.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Hash Join")) {
									output += "a Hash Join Operation.";
									root++;
								}

								
								else if (element.getFirstChild().getNodeValue()
										.equals("Append")) {
									output += "an Append Operation.";
									root++;
								}

								else if (element.getFirstChild().getNodeValue()
										.equals("Seq Scan")) {
									output += "a Sequential Scan Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Hash")) {
									output += "a Hash Operation.";
									root++;
								}

								else if (element.getFirstChild().getNodeValue()
										.equals("Nested Loop")) {

									output += "a Nested Loop Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Index Scan")) {
									output += "an Index Scan Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Sort")) {
									output += "a Sort Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue()
										.equals("Bitmap Heap Scan")) {
									
									output += "a Bitmap Heap Scan Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue()
										.equals("Bitmap Index Scan")) {
									output += "a Bitmap Index Scan Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Merge Join")) {
									output += "a Merge Join Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue()
										.equals("Index Only Scan")) {
									output += "an Index Only Scan Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Materialize")) {
									output += "a Materialize Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Unique")) {
									output += "an Unique Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Limit")) {
									output += "a Limit Operation.";
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Subquery Scan")) {
									output += "a Subquery Scan Operation.";
									
									
									root++;
								} else if (element.getFirstChild()
										.getNodeValue().equals("Group")) {
									output += "a Group Operation.";
									root++;
								}
							}
						}

						if (root != 1) {// sub branch
							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Hash Join")) {
									Element temp = (Element) nodeList
											.item(i + 12);
									String relations = temp.getFirstChild()
											.getNodeValue();
									relations = relations.replace("\"", "");
									relations = relations.replace("(", "");
									relations = relations.replace(")", "");
									relations = relations.replace(" ", "");
									relations = relations.replace("_", "");
									relations = relations.replace("1", "");
									relations = relations.replace("2", "");
									relations = relations.replace("3", "");
									relations = relations.replace("4", "");
									relations = relations.replace("5", "");
									relations = relations.replace("6", "");
									relations = relations.replace("7", "");
									relations = relations.replace("8", "");
									String[] relation = relations.split("=");
									String relation1 = relation[0];
									
									String relation2 = relation[1];
									String[] r1 = relation1.split("\\.");
									String[] r2 = relation2.split("\\.");

									if (hashsJoin == 0) {
										hashJoin += "In the Sub Branches, Hash Join Operations are performed between "
												+ r1[0] + " and " + r2[0];
										hashsJoin++;
									} else {
										hashJoin += "," + r1[0] + " and "
												+ r2[0];
									}

								}
							}

						}

						if (root != 1) {// sub branch
							boolean skip = false;
							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Sort")) {

									noOfSort++;
									Element temp = (Element) nodeList
											.item(i + 14);
									if (temp.getNodeName().equals(
											"Sort-Space-Used")) {
										temp = (Element) nodeList.item(i + 13);
									}
									
									
									String col = temp.getFirstChild()
											.getNodeValue();
									for (int t = 0; t < sortlist.size(); t++) {
										if ((col.equals(sortlist.get(t)))) {
											skip = true;
										}
									}
									if (skip != true) {
										if (noOfSort == 1) {
											sortMethod += temp.getFirstChild()
													.getNodeValue();

										} else {
											sortMethod += ","
													+ temp.getFirstChild()
															.getNodeValue();
										}
									}
									sortlist.add(col);
								}
							}
						}

						
			
						// Handle Scanning Operations
						if (root != 1) {// sub branch
							boolean skip = false;

							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Seq Scan")) {
									Element temp = (Element) nodeList
											.item(i + 3);
									Element filters = (Element) nodeList
											.item(i + 13);
									String filter = filters.getNodeName();
	
									String column = temp.getFirstChild()
											.getNodeValue();

									for (int j = 0; j < list.size(); j++) {
										if ((column.equals(list.get(j)))) {
											skip = true;
										}
									}
							
									if (skip != true) {
										if (seqsScan == 0 && hashsJoin == 0) {
											seqScan += "In the Sub Branches, Sequential Scan Operations are performed on "
													+ column + " tables";
											if (filter.equals("Filter")) {
												String filterContent = filters
														.getFirstChild()
														.getNodeValue();
												filterContent = filterContent
														.replace("::text", "");
												filterContent = filterContent
														.replace("(", "");
												filterContent = filterContent
														.replace(")", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												seqScan += " using filter ("
														+ filterContent + ")";
											}

											list.add(column);
											seqsScan++;
										} else if (seqsScan == 0
												&& hashsJoin != 0) {
											seqScan += "Sequential Scan Operations are also performed on "
													+ column + " tables";
											if (filter.equals("Filter")) {
												String filterContent = filters
														.getFirstChild()
														.getNodeValue();
												filterContent = filterContent
														.replace("::text", "");
												filterContent = filterContent
														.replace("(", "");
												filterContent = filterContent
														.replace(")", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												seqScan += " using filter ("
														+ filterContent + ")";
											}
											list.add(column);
											seqsScan++;
										} else {

											seqScan += "," + column + " tables";
											if (filter.equals("Filter")) {
												String filterContent = filters
														.getFirstChild()
														.getNodeValue();
												filterContent = filterContent
														.replace("::text", "");
												filterContent = filterContent
														.replace("(", "");
												filterContent = filterContent
														.replace(")", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												filterContent = filterContent
														.replace("&gt;=", "");
												seqScan += " using filter ("
														+ filterContent + ")";
											}
											list.add(column);
											seqsScan++;
										
										}

									}

								}
							}

						}

						if (root != 1) {// sub branch

							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Bitmap Heap Scan")) {

									noOfBitmapHeapScan++;
									noOfBitmapHeapScanTables++;
									Element tables = (Element) nodeList
											.item(i + 3);
									String bhsTable = tables.getFirstChild()
											.getNodeValue();
									if (noOfBitmapHeapScanTables == 1) {
										bitmapTables += bhsTable;

									} else
										bitmapTables += "," + bhsTable;

								}
							}
						}

						// Bitmap index scan

						if (root != 1) {// sub branch

							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Bitmap Index Scan")) {
									Element cond = (Element) nodeList
											.item(i + 12);
									String acond = cond.getFirstChild()
											.getNodeValue();
									acond = acond.replaceAll("::text", "");
									acond = acond.replace("(", "");
									acond = acond.replace(")", "");
									noOfBitmapIndexScan++;
									if (noOfBitmapIndexScan == 1)
										bitmapIndexScan += acond;
									else
										bitmapIndexScan += "," + acond;
								}
							}
						}

						// Index scan

						
						
						

						
						
						if (root != 1) {// sub branch
							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Index Scan")) {
									noOfIndexScan++;
									Element tableNode = (Element) nodeList
											.item(i + 5);
									Element tkey = (Element) nodeList
											.item(i + 4);
									Element tfilter = (Element) nodeList
											.item(i + 15);
									String table = tableNode.getFirstChild()
											.getNodeValue();
									String key = tkey.getFirstChild()
											.getNodeValue();
									String filter = tfilter.getFirstChild()
											.getNodeValue();
									filter = filter.replaceAll("::text", "");
									filter = filter.replace("(", "");
									filter = filter.replace(")", "");
									if (noOfIndexScan == 1) {
										indexScan += "Index Scan(s) are used on "
												+ table
												+ " table using "
												+ key
												+ " key";
										if (tfilter.getNodeName() == "Filter") {

											indexScan += " with " + filter
													+ " filter";
											
											
											
										} else if (tfilter.getNodeName() == "Index-Cond") {
											indexScan += " with " + filter
													+ " condition";

											Element tfilter2 = (Element) nodeList
													.item(i + 17);
											if (tfilter2.getNodeName() == "Filter") {
												String filter2 = tfilter2
														.getFirstChild()
														.getNodeValue();
												filter2 = filter2.replaceAll(
														"::text", "");
												filter2 = filter2.replace("(",
														"");
												filter2 = filter2.replace(")",
														"");
												indexScan += " and " + filter2;
											}
										}
									} else if (noOfIndexScan > 1) {
										if (tfilter.getNodeName() == "Filter") {
											indexScan += ", " + table
													+ " using " + key
													+ " key with " + filter
													+ " filter";
										} else if (tfilter.getNodeName() == "Index-Cond") {
											Element tfilter2 = (Element) nodeList
													.item(i + 17);
											if (tfilter2.getNodeName() == "Filter") {

												String filter2 = tfilter2
														.getFirstChild()
														.getNodeValue();
												filter2 = filter2.replaceAll(
														"::text", "");
												filter2 = filter2.replace("(",
														"");
												filter2 = filter2.replace(")",
														"");
												indexScan += ", " + table
														+ " using " + key
														+ " key with " + filter
														+ " filter and "
														+ filter2
														+ " condition";
											} else {
												indexScan += ", " + table
														+ " using " + key
														+ " key with " + filter
														+ " condition";
											}
										} else
											indexScan += ", " + table
													+ " using " + key + " key";
									}
								}
							}
						}

						// Index only Scan
						if (root != 1) {// sub branch

							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Index Only Scan")) {
									noOfIndexOnlyScan++;
									Element tableNode = (Element) nodeList
											.item(i + 5);
									Element tkey = (Element) nodeList
											.item(i + 4);
									Element tfilter = (Element) nodeList
											.item(i + 15);
									String table = tableNode.getFirstChild()
											.getNodeValue();
									String key = tkey.getFirstChild()
											.getNodeValue();
									String filter = tfilter.getFirstChild()
											.getNodeValue();
									filter = filter.replaceAll("::text", "");
									filter = filter.replace("(", "");
									filter = filter.replace(")", "");
									if (noOfIndexOnlyScan == 1) {
										indexOnlyScan += "Index Only Scan(s) are used on "
												+ table
												+ " table using "
												+ key
												+ " key";
										if (tfilter.getNodeName() == "Filter") {
											indexOnlyScan += " with " + filter
													+ " filter";
										} else if (tfilter.getNodeName() == "Index-Cond") {
											indexOnlyScan += " with " + filter
													+ " condition";

											Element tfilter2 = (Element) nodeList
													.item(i + 17);
											if (tfilter2.getNodeName() == "Filter") {
												String filter2 = tfilter2
														.getFirstChild()
														.getNodeValue();
												filter2 = filter2.replaceAll(
														"::text", "");
												filter2 = filter2.replace("(",
														"");
												filter2 = filter2.replace(")",
														"");
												indexScan += " and " + filter2;
											}
										}
									} else if (noOfIndexOnlyScan > 1) {
										if (tfilter.getNodeName() == "Filter") {
											indexOnlyScan += ", " + table
													+ " using " + key
													+ " key with " + filter
													+ " filter";
										} else if (tfilter.getNodeName() == "Index-Cond") {
											Element tfilter2 = (Element) nodeList
													.item(i + 17);
											if (tfilter2.getNodeName() == "Filter") {

												String filter2 = tfilter2
														.getFirstChild()
														.getNodeValue();
												filter2 = filter2.replaceAll(
														"::text", "");
												filter2 = filter2.replace("(",
														"");
												filter2 = filter2.replace(")",
														"");
												indexOnlyScan += ", " + table
														+ " using " + key
														+ " key with " + filter
														+ " filter and "
														+ filter2
														+ " condition";
											} else {
												indexOnlyScan += ", " + table
														+ " using " + key
														+ " key with " + filter
														+ " condition";
											}
										} else
											indexOnlyScan += ", " + table
													+ " using " + key + " key";
									}
								}
							}
						}

						// Merge Join
						if (root != 1) {// sub branch

							// TO DO skip repeated
							boolean skip = false;

							if (element.getNodeName().equals("Node-Type")) {
								if (element.getFirstChild().getNodeValue()
										.equals("Merge Join")) {

									Element mergeCond = (Element) nodeList
											.item(i + 11);

									if (!mergeCond.getNodeName().equals(
											"Merge-Cond")) {
										mergeCond = (Element) nodeList
												.item(i + 12);
									}

									String mCond = mergeCond.getFirstChild()
											.getNodeValue();
									mCond = mCond.replace("(", "");
									mCond = mCond.replace(")", "");
									mCond = mCond.replace("_", "");
									mCond = mCond.replace("1", "");
									mCond = mCond.replace("2", "");
									mCond = mCond.replace("3", "");
									mCond = mCond.replace("4", "");
									mCond = mCond.replace("5", "");
									mCond = mCond.replace("6", "");
									mCond = mCond.replace("7", "");
									mCond = mCond.replace("8", "");
									for (int k = 0; k < mergelist.size(); k++) {
										if ((mCond.equals(mergelist.get(k)))) {
											skip = true;
										}
									}
									if (skip != true) {

										noOfMergeJoins++;
										if (noOfMergeJoins == 1)
											mergeJoins += "Merge Join(s) was used with conditons "
													+ mCond;
										else {
											mergeJoins += "," + mCond;
										}

									}
									mergelist.add(mCond);
								}

							}
						}

					}

					if (element.getNodeName().equals("Planning-Time")) {

						planningTime = "The planning time of this query plan is "
								+ element.getFirstChild().getNodeValue()
								+ " milliseconds";

					}
					if (element.getNodeName().equals("Execution-Time")) {

						exeTime = " and actual execution time of this query is "
								+ element.getFirstChild().getNodeValue()
								+ " milliseconds.";

					}

					// System.out.println(element.getNodeName() + ": " +
					// element.getFirstChild().getNodeValue());

				}
				String sortMethodPural = "The method(s) that were used for the Sort Operations are "
						+ sortMethod;
				String sortMethodSingluar = "The method that was used for the Sort Operation is "
						+ sortMethod;
				String bitmapHeapScanTables = "The tables that Bitmap Heap Scan Operation was performed on are "
						+ bitmapTables;
				String bitmapHeapScanTable = "The table that Bitmap Heap Scan Operation was performed on is "
						+ bitmapTables;
				if (hashsJoin > 0) {
					hashJoin += ".\n";
				}

				if (noOfIndexOnlyScan > 0) {
					indexOnlyScan += ".\n";
				}
				if (noOfIndexScan > 0) {
					indexScan += ".\n";
				}
				if (seqsScan > 0) {
					seqScan += ".\n";
				}
				String finalSortM = "";
				String finalBitMapTable = "";
				bitmapIndexScan += ".";
				if (noOfMergeJoins > 0) {
					mergeJoins += ".\n";
				}
				if (noOfSort > 1) {
					finalSortM = sortMethodPural + ".\n";
				} else if (noOfSort == 1)
					finalSortM = sortMethodSingluar + ".\n";

				if (noOfBitmapHeapScanTables > 1) {
					finalBitMapTable = bitmapHeapScanTables + ".\n";
				} else if (noOfBitmapHeapScanTables == 1)
					finalBitMapTable = bitmapHeapScanTable + ".\n";
				if (noOfBitmapHeapScan > 1) {
					bitmapHeapScan += noOfBitmapHeapScan
							+ " instances of Bitmap Heap Scan were performed during this Query.\n";
				}

				String bitmapIndexInstance = "";
				if (noOfBitmapIndexScan > 0) {
					bitmapIndexInstance += "There are "
							+ noOfBitmapIndexScan
							+ " instance of Bitmap Index Scan performed during this Query using condition(s) "
							+ bitmapIndexScan + "\n";
				}
				String ttscOutput = output + hashJoin + seqScan + finalSortM
						+ bitmapHeapScan + finalBitMapTable
						+ bitmapIndexInstance + indexScan + indexOnlyScan
						+ mergeJoins + planningTime + exeTime;

				/*System.out.println(output + "\n" + hashJoin + seqScan
						+ finalSortM + bitmapHeapScan + finalBitMapTable
						+ bitmapIndexInstance + indexScan + indexOnlyScan
						+ mergeJoins + planningTime + exeTime);
						*/
				
				try{
				speak(ttscOutput);
				}
				catch (Exception e){
					TextToSpeechConvertor ttsc = new TextToSpeechConvertor();
					ttsc.speak(ttscOutput);
				}
				//Audio.getInstance().play(Audio.getInstance().getAudio("This is my test", Language.ENGLISH));		
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Invalid Query!");

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}
	
	public static void speak(String text) {
		System.out.println(text);
		
		//Create a new Thread because JLayer is running on the current Thread and will make the application to lag
		Thread thread = new Thread(() -> {
			try {
				
				//Create a JLayer instance
				AdvancedPlayer player = new AdvancedPlayer(synthesizer.getMP3Data(text));
				player.play();
				
				System.out.println("Successfully got back synthesizer data");
				
			} catch (IOException | JavaLayerException e) {
				
				e.printStackTrace(); //Print the exception ( we want to know , not hide below our finger , like many developers do...)
				
			}
		});
		
		//We don't want the application to terminate before this Thread terminates
		thread.setDaemon(false);
		
		//Start the Thread
		thread.start();
		
	}

}
